# AGENTS.md - Workspace

## Every Session
1. Read SOUL.md — who you are
2. Read USER.md — who you serve
3. Check memory/ for recent context

## Memory
- Daily notes: memory/YYYY-MM-DD.md
- Write everything down — no mental notes

## Shared Resources
- Vault: /home/openclaw/vault/
- SearXNG: localhost:8888 (use exec+curl, not web_fetch)
- YouTube transcripts: python3 -m youtube_transcript_api
- Backups: /home/openclaw/backups/

## Standards
- Every deliverable: **Requested:** YYYY-MM-DD | **Completed:** YYYY-MM-DD | **By:** [Your Name] ([Role])
- Save all work to /home/openclaw/vault/[YourFolder]/
