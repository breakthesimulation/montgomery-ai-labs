# Memory - Dev (CTO)

## Agent Context
- **Role:** Dev, CTO of Montgomery AI Labs
- **Workspace:** /home/openclaw/.openclaw/workspace-dev/
- **Human:** Sebastian Montgomery (CEO)
- **Telegram:** @SebMontgomery

## Priorities (from SOUL.md)
1. Trading bots (PolyMarket, crypto, stocks)
2. Agent infrastructure improvements
3. Validator.com tech
4. Content tooling

## Technical Stack
- Python, JavaScript/Node.js, Solana/Web3
- Trading bots, APIs, automation
- OpenClaw agent infrastructure

## ⚡ Operating Mode
- NON-STOP BUILD MODE
- Use full API capacity (~1000 msg/5hrs)
- Report to Bert (main) every 3-5 tasks completed

## Research & References (in workspace)
- `hyperliquid-api-notes.md` - Hyperliquid exchange API documentation
- `backpack-okx-api-notes.md` - Backpack/OKX exchange API notes
- `trading-strategies-research.md` - Trading strategy research
- `trading-bot-roadmap.md` - Trading bot development roadmap
- `projects/solana-calendar/` - Solana event calendar project

## Active Projects
- **AI Doomer** - Next.js 14 + Tailwind doomer aesthetic site at https://ai-doomer.vercel.app
  - Aggregates AI news, tracks 20 AI leaders
  - Uses SearXNG at localhost:8888 via API proxy on port 3458
  - Files: `/vault/Dev/ai-doomer/` (Next.js), `/vault/Dev/ai-doomer-api/` (proxy)
  - Status: API proxy online, verifying live headlines
- **Trading Analysis System:** Ensure live paper trading before real money

## Technical Notes
- Pine Script strategies developed: rsi_profit_strategy, multi_profit_scanner, profit_analyzer
- Focus on stock/crypto TA system with RSI, MACD, Bollinger Bands, EMA crossovers
- Automated signal generation → Telegram alerts priority
## 2026-02-24-25 Learnings

### Cron Fixes (Feb 2026)
- AI + OpenClaw News Summary cron jobs failing because:
  - Using `gemini-2.0-flash` model - too weak, just describes what it would do instead of executing
  - Message tool validation error when trying to send to Telegram
- Fix: Changed model to `claude-sonnet-4-6` (the one that successfully delivered on Feb 23)
- Also increased timeout to 600s (was default ~60s)
- Fixed datetime timezone bug: `datetime.now()` vs `datetime.now(timezone.utc)` - always use timezone-aware
- Fixed missing `import requests` in hl-paper-integration.py - caused live_price to return None silently
- Added hard fail when live prices unavailable - refuse to use stale data
- Consolidated TRADES_FILE to single path: /home/openclaw/public/data/hl_paper_trades.json
- fib_ew.py created as symlink to 2026-02-22-fib-ew-engine.py

### Cron Issues
- OpenClaw cron jobs failing due to auth-profiles.json permission error
- System crontab works fine as fallback

### UI Improvements
- Glassmorphism portfolio tracker
- Doomer aesthetic for AI Doomer (amber-red accents)
- Static JSON fallback for Vercel API routes (proxy doesn't work from Vercel)

### Vercel Deployments
- Static JSON files must go in /data/ folder to be served
- .vercelignore can block files - check deployment file list
- Alias routing separate from direct URL

### Task Logging
- Keep /vault/Dev/task-log.md updated with all work done
- Helps track what was accomplished vs time spent

### 2026-02-26-27 Learnings
- Fixed datetime timezone bug: `datetime.now()` vs `datetime.now(timezone.utc)` - always use timezone-aware
- Fixed missing `import requests` in hl-paper-integration.py - caused live_price to return None silently
- Added hard fail when live prices unavailable - refuse to use stale data
- Consolidated TRADES_FILE to single path: /home/openclaw/public/data/hl_paper_trades.json
- OpenClaw cron jobs failing due to auth-profiles.json permission error
- UI improvements: Glassmorphism portfolio tracker, Doomer aesthetic for AI Doomer (amber-red accents), Static JSON fallback for Vercel API routes (proxy doesn't work from Vercel)
- Vercel deployment notes: Static JSON files must go in /data/ folder to be served, .vercelignore can block files - check deployment file list, Alias routing separate from direct URL

### Task Logging
- Keep /vault/Dev/task-log.md updated with all work done
- Helps track what was accomplished vs time spent
