## ⚠️ CRITICAL OUTPUT RULE
**ALL deliverables MUST be saved to the Obsidian vault:** `/home/openclaw/vault/`
- Your folder: `/home/openclaw/vault/Dev/`
- Never save final outputs only to workspace — Seb reviews everything via Obsidian
- workspace files are for working drafts only
- **File naming:** `YYYY-MM-DD-descriptive-name.md` (e.g. `2026-02-19-fogees-hub-copy-v1.md`) — ALWAYS date prefix
- Every vault file MUST have this frontmatter at the top:

```
---
created: YYYY-MM-DD HH:MM UTC
from: Dev
tags:
  - dev
status: draft|reference|final
note: Brief description of file
---
```

# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

### Pine Script Tester

- Location: `/home/openclaw/vault/Dev/trading-bot/pine_tester/`
- Purpose: Test TradingView Pine scripts against historical OHLCV data
- Usage: `python3 -m pytest tests/test_pine_strategy.py -v`
- Strategies: rsi_only, macd_only, rsi_macd, sr_only, combined

```python
# Quick test
from pine_tester import run_strategy_test
from tests.test_data_generator import MarketCondition

result = await run_strategy_test(symbol="BTC", timeframe="1m", 
                                  condition=MarketCondition.BULL,
                                  strategy_name="combined")
```

Add whatever helps you do your job. This is your cheat sheet.

## YouTube Access
- **YouTube Data API v3** — primary method, no IP issues, free
  - Key stored in: `.secrets/youtube.env` (YOUTUBE_API_KEY)
  - Usage: load key → `googleapis.com/youtube/v3/...`
  - Gets: video metadata, captions, search, channel info

## Recent Fixes

### Trading System
- fib_ew.py symlink: `ln -s /home/openclaw/vault/Dev/trading-system/2026-02-22-fib-ew-engine.py /home/openclaw/vault/Dev/trading-system/fib_ew.py`
- Cron: `0 * * * * cd /home/openclaw/vault/Dev/trading-system && python3 fib_ew.py >> trading-system/fib_ew.log 2>&1`
- Trades file fix: /home/openclaw/public/data/hl_paper_trades.json

### Vercel
- Static JSON in /data/ folder works, /api/ folder gets proxied
- Use --force flag to force redeploy
