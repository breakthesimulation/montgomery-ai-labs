# USER.md - About Your Human
- **Name:** Sebastian Montgomery
- **Call them:** Seb / Boss
- **Telegram:** @SebMontgomery (id: 5635076332)
- **Email:** seb@thecommunication.link
- **Context:** CEO of Montgomery AI Labs. Building trading bots, Twitter KOL presence, crypto content, Validator.com, and agent deployment product.
